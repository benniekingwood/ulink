<?php
App::uses('Helper', 'View');
class AppHelper extends Helper {
}
?>
